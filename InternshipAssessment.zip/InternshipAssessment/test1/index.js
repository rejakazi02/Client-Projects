

const btnn = document.querySelector("#container").setAttribute("style", "display: grid; grid-template-row: repeat(5, 1fr);"); 
document.querySelector("#card1").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card2").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card3").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card4").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card5").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 



function layoutOne() {

document.querySelector("#container").setAttribute("style", "display: grid; grid-template-row: repeat(5, 1fr);"); 
document.querySelector("#card1").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card2").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card3").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card4").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 
document.querySelector("#card5").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 90%;height: 100px;"); 

}


function layouTwo() {

document.querySelector("#container").setAttribute("style", "display: grid; grid-template-columns: repeat(3, 1fr);"); 
document.querySelector("#card1").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; height: 300px;"); 
document.querySelector("#card2").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; height: 300px;"); 
document.querySelector("#card3").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; height: 300px;"); 
document.querySelector("#card4").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; height: 300px;"); 
document.querySelector("#card5").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; height: 300px;"); 

}


function layoutThree() {

document.querySelector("#container").setAttribute("style", "display: flex;flex-wrap: wrap;"); 
document.querySelector("#card1").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 100%;height: 100px; ");
document.querySelector("#card2").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: grid; grid-template-colums: .3fr; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 15%;height: 280px;"); 
document.querySelector("#card3").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: grid; grid-template-colums: .5fr; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 54%;height: 280px;"); 
document.querySelector("#card4").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: grid; grid-template-colums: .3fr; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 15%;height: 280px;"); 
document.querySelector("#card5").setAttribute("style", "background-color: #da1e5d; margin: 35px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 10px; width: 100%;height: 100px; "); 
}


